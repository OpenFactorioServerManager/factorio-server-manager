data:extend {
    {
        type = "item",
        name = "balancer-part",
        icon = "__belt-balancer__/graphics/icons/balancer.png",
        icon_size = 200,
        subgroup = "belt",
        order = "c[splitter]-x[balancer]",
        place_result = "balancer-part",
        stack_size = 50
    },
}
